<?php get_header(); ?>

<section aria-label="section" class="no-bottom">
                <div class="container">
                    <div class="row">
                        
                       <?php while(have_posts() ) : the_post(); ?>

                           <?php get_template_part('template-part/content'); ?>

                       <?php endwhile; ?>     

                       

                    </div>
                </div>
            </section>

<?php get_footer(); ?>