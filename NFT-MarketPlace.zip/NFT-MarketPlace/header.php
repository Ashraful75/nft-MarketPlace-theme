<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">

<head>
    <title>Gigaland - NFT Marketplace Website Template</title>
    <link rel="icon" href="images/icon.png" type="image/gif" sizes="16x16">
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="Gigaland - NFT Marketplace Website Template" name="description" />
    <meta content="" name="keywords" />
    <meta content="" name="author" />

    <?php wp_head(); ?>
</head>

<body <?php body_class($class="dark-scheme de-grey"); ?> >
    <div id="wrapper">
            <!-- header begin -->
        <header class="transparent scroll-dark">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="de-flex sm-pt10">
                            <div class="de-flex-col">
                                <div class="de-flex-col">
                                    <!-- logo begin -->
                                    <div id="logo">
                                        <a href="<?php echo home_url(); ?>">
                                            <?php $nft = get_option('nft_option'); ?>

                                            <img alt="" src="<?php echo $nft['site-logo']['url']; ?>" />
                                        </a>
                                    </div>
                                    <!-- logo close -->
                                </div>
                                <div class="de-flex-col">
                                    <input id="quick_search" class="xs-hide style-2" name="quick_search" placeholder="search item here..." type="text" />
                                </div>
                            </div>
                            <div class="de-flex-col header-col-mid">
                                <!-- mainmenu begin -->
                                <ul id="mainmenu">
                                    <li>
                                        <a href="03_grey-index.html">Home<span></span></a>
                                        <ul>
                                            <li><a href="03_grey-index.html">Homepage 1</a></li>
                                            <li><a href="03_grey-index-2.html">Homepage 2</a></li>
                                            <li><a href="03_grey-index-3.html">Homepage 3</a></li>
                                            <li><a href="03_grey-index-4.html">Homepage 4</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="03_grey-explore.html">Explore<span></span></a>
                                        <ul>
                                            <li><a href="03_grey-explore.html">Explore</a></li>
                                            <li><a href="03_grey-explore-2.html">Explore 2</a></li>
                                            <li><a href="03_grey-collection.html">Collections</a></li>
                                            <li><a href="03_grey-live-auction.html">Live Auction</a></li>
                                            <li><a href="03_grey-item-details.html">Item Details</a></li>
                                            <li><a href="03_grey-help-center.html">Help Center</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="03_grey-author.html">Author<span></span></a>
                                        <ul>
                                            <li><a href="03_grey-author.html">Author</a></li>
                                            <li><a href="03_grey-profile.html">Profile</a></li>
                                            <li><a href="03_grey-wallet.html">Wallet</a></li>
                                            <li><a href="03_grey-create-options.html">Create</a></li>
                                            <li><a href="03_grey-login.html">Login</a></li>
                                        </ul>
                                    </li>                                    
                                    <li>
                                        <a href="#">Stats<span></span></a>
                                        <ul>
                                            <li><a href="03_grey-activity.html">Activity</a></li>
                                            <li><a href="03_grey-rankings.html">Rankings</a></li>
                                        </ul>
                                    </li>
                                </ul>
                                <!-- mainmenu close -->
                                <div class="menu_side_area">
                                    <?php if($nft['switcher-wallet'] == 1) : ?>
                                    <a href="<?php echo $nft['link-walet']['url']; ?>" class="btn-main btn-wallet"><i class="icon_wallet_alt"></i><span><?php echo $nft['link-walet']['text']; ?></span></a>
                                <?php endif; ?>
                        
                                    <span id="menu-btn"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- header close -->