<?php
/**
 * Functions and definitions
 *
 * @package WordPress
 * @subpackage NFTMarketPlace
 * @since NFTMarketPlace 1.0.0
 */
/* NFTMarketPlace include files  */






// This theme requires WordPress 5.3 or later.


function nftmarketplace_theme_setup(){
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on NFTMarketPlace, use a find and replace
		 * to change 'NFTMarketPlace' to the name of your theme in all the template files.
		 */

		load_theme_textdomain('nft', get_template_directory().'/languages');
		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * This theme does not use a hard-coded <title> tag in the document head,
		 * WordPress will provide it for us.
		 */
		add_theme_support( 'title-tag' );


		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		set_post_thumbnail_size( 1568, 9999 );

		/* register menu */

		register_nav_menus(
			array(
				'Main Mneu' => esc_html__( 'Primary menu', 'NFT' ),
				'footer'  => __( 'Secondary menu', 'NFT' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
				'navigation-widgets',
			)
		);





}
add_action('after_setup_theme', 'nftmarketplace_theme_setup');


/*** css file call */

function nftmarketplace_theme_css_files(){

	wp_enqueue_style('bootstrap', get_template_directory_uri().'/css/bootstrap.min.css');

    wp_enqueue_style('bootstrap-grid', get_template_directory_uri().'/css/bootstrap-grid.min.css');

    wp_enqueue_style('bootstrap-reboot', get_template_directory_uri().'/css/bootstrap-reboot.min.css');

    wp_enqueue_style('animate', get_template_directory_uri().'/css/animate.css');
    wp_enqueue_style('owl-carousel', get_template_directory_uri().'/css/owl.carousel.css');
    wp_enqueue_style('owl-theme', get_template_directory_uri().'/css/owl.theme.css');
    wp_enqueue_style('transitions', get_template_directory_uri().'/css/owl.transitions.css');
    wp_enqueue_style('magnific-popup', get_template_directory_uri().'/css/magnific-popup.css');
    wp_enqueue_style('jquery-countdown', get_template_directory_uri().'/css/jquery.countdown.css');
    wp_enqueue_style('main-style', get_template_directory_uri().'/css/style.css');
    wp_enqueue_style('de-grey', get_template_directory_uri().'/css/de-grey.css');

    wp_enqueue_style('scheme-01', get_template_directory_uri().'/css/colors/scheme-01.css');
    wp_enqueue_style('coloring', get_template_directory_uri().'/css/coloring.css');
    wp_enqueue_style('style', get_stylesheet_uri() );
    wp_enqueue_style( 'fa5', 'https://use.fontawesome.com/releases/v5.13.0/css/all.css');

}
add_action('wp_enqueue_scripts', 'nftmarketplace_theme_css_files');

/* js files call */

function nftmarketplace_theme_js_scripts(){
	 wp_enqueue_script('jquery', get_template_directory_uri().'/js/jquery.min.js', array('jquery'), '', true);

    wp_enqueue_script('bootstrap-js', get_template_directory_uri().'/js/bootstrap.min.js', array('jquery'), '', true);
    wp_enqueue_script('bootstrap-bundle', get_template_directory_uri().'/js/bootstrap.bundle.min.js', array('jquery'), '', true);
    wp_enqueue_script('wow-min', get_template_directory_uri().'/js/wow.min.js', array('jquery'), '', true);
    wp_enqueue_script('isotope', get_template_directory_uri().'/js/jquery.isotope.min.js', array('jquery'), '', true);
    wp_enqueue_script('easing', get_template_directory_uri().'/js/easing.js', array('jquery'), '', true);
    wp_enqueue_script('owl-carousel', get_template_directory_uri().'/js/owl.carousel.js', array('jquery'), '', true);
    wp_enqueue_script('validation', get_template_directory_uri().'/js/validation.js', array('jquery'), '', true);

    wp_enqueue_script('magnific-popup', get_template_directory_uri().'/js/jquery.magnific-popup.min.js', array('jquery'), '', true);
    wp_enqueue_script('enquire', get_template_directory_uri().'/js/enquire.min.js', array('jquery'), '', true);
    wp_enqueue_script('jquery-plugin', get_template_directory_uri().'/js/jquery.plugin.js', array('jquery'), '', true);
    wp_enqueue_script('jquery-countTo', get_template_directory_uri().'/js/jquery.countTo.js', array('jquery'), '', true);
    wp_enqueue_script('countdown', get_template_directory_uri().'/js/jquery.countdown.js', array('jquery'), '', true);
    wp_enqueue_script('lazy', get_template_directory_uri().'/js/jquery.lazy.min.js', array('jquery'), '', true);
    wp_enqueue_script('lazy-plugins', get_template_directory_uri().'/js/jquery.lazy.plugins.min.js', array('jquery'), '', true);
    wp_enqueue_script('designesia', get_template_directory_uri().'/js/designesia.js', array('jquery'), '', true);
    wp_enqueue_script('particles', get_template_directory_uri().'/js/particles.js', array('jquery'), '', true);
    wp_enqueue_script('particles-settings', get_template_directory_uri().'/js/particles-settings.js', array('jquery'), '', true);
}
add_action('wp_enqueue_scripts', 'nftmarketplace_theme_js_scripts');

/*** Register widget area. */

function nft_marketplace_widget_init() {

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer First Widget', 'nft' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here to appear in your footer.', 'nft' ),
			'before_widget' => '<div class="widget">',
			'after_widget'  => '</div>',
			'before_title'  => '<h5 class="widget-title">',
			'after_title'   => '</h5>',
		)
	);


	register_sidebar(
		array(
			'name' 			=> esc_html__('Footer Second Widget', 'nft'),
			'id' 			=> 'sidebar-2',
			'description' 	=> esc_html__('Add Widgets Here to appear in your footer.', 'nft'),
			'before_widget' => '<div class="widget">',
			'after_widget' 	=> '</div>',
			'before_title' 	=> '<h5 class="widget-title">',
			'after_title' 	=> '</h5>',
		));

	register_sidebar(
		array(
			'name' 			=> esc_html__('Footer Third Widget', 'nft'),
			'id' 			=> 'sidebar-3',
			'description' 	=> esc_html__('Add Widgets Here to appear in your footer.', 'nft'),
			'before_widget' => '<div class="widget">',
			'after_widget' 	=> '</div>',
			'before_title' 	=> '<h5 class="widget-title">',
			'after_title' 	=> '</h5>',
		));

	register_sidebar(
		array(
			'name' 			=> esc_html__('Footer Last Widget', 'nft'),
			'id' 			=> 'sidebar-4',
			'description' 	=> esc_html__('Add Widgets Here to appear in your footer.', 'nft'),
			'before_widget' => '<div class="widget">',
			'after_widget' 	=> '</div>',
			'before_title' 	=> '<h5 class="widget-title">',
			'after_title' 	=> '</h5>',
		));
	
}
add_action( 'widgets_init', 'nft_marketplace_widget_init' );




if(file_exists( dirname(__FILE__).'/theme-options/csf/codestar-framework.php')){
    require_once( dirname(__FILE__).'/theme-options/csf/codestar-framework.php');
}

if(file_exists( dirname(__FILE__).'/theme-options/csf/codestar-framework.php')){
    require_once( dirname(__FILE__).'/theme-options/csf/samples/admin-options.php');
}