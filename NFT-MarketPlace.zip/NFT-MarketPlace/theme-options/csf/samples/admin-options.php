<?php if ( ! defined( 'ABSPATH' )  ) { die; } // Cannot access directly.

//
// Set a unique slug-like ID
//
$prefix = 'nft_option';

//
// Create options
//
CSF::createOptions( $prefix, array(
  'menu_title' => 'NFT Options',
  'menu_slug'  => 'csf-demo',
) );

//
// Create a section
//

CSF::createSection($prefix, array(
  'title' => 'Header Option',
  'icon' => '',
  'id' => 'header-parent',
));

CSF::createSection($prefix, array(
  'title' => 'Logo',
  'icon'  => 'fas fa-images',
  'parent' => 'header-parent',
  'fields' => array(
      array(
        'id' => 'site-logo',
        'type' => 'media',
        'title' => 'Website Logo',
      ),

  ),
));

CSF::createSection($prefix, array(
  'title' => 'Wallet Menu Link',
  'icon'  => 'fas fa-external-link-square-alt',
  'parent' => 'header-parent',
  'fields' => array(
    
      array(
        'id' => 'link-walet',
        'type' => 'link',
        'title' => 'Walet Menu Link',
      ),
      array(
        'id' => 'switcher-wallet',
        'type' => 'switcher',
        'title' => 'Switcher Wallet'
      )

  ),
));


CSF::createSection($prefix, array(
  'title' => __('Footer Section', 'nft'),
  'id' => 'footer-section',
  'icon' => '',
));

CSF::createSection($prefix, array(
  'title' => __('Footer Copy Right', 'nft'),
  'id' => 'footer-copyright',
  'icon'  => 'fas fa-copyright',
  'parent' => 'footer-section',
  'fields' => array(

    array(
      'id' => 'copyright-text',
      'title' => __('Footer Copyright Text', 'nft'),
      'type' => 'text',
    ),

  ),
));

CSF::createSection($prefix, array(
  'title' => __('Footer Footer Social', 'nft'),
  'id' => 'footer-social',
  'icon'  => 'fas fa-share-alt-square',
  'parent' => 'footer-section',
  'fields' => array(

    array(
      'id' => 'social-icons',
      'title' => __('Footer Social Icons', 'nft'),
      'type' => 'group',
      'fields' => array(
        array(
          'id' => 'icon-name',
          'title' => __('Social Icon Name', 'nft'),
          'type' => 'text',
        ),
        array(
          'id' => 'select-icon',
          'title' => __('Select your Social Icon', 'nft'),
          'type' => 'icon',
        ),
        array(
          'id' => 'select-icon-link',
          'title' => __('Put your Social Icon', 'nft'),
          'type' => 'text',
        ),


      )
      
    ),
    
  ),
));


