<?php get_header(); ?>
<div class="spacer-single"></div>
<div class="no-bottom no-top" id="content">
<div id="top"></div>
<section aria-label="section" class="no-bottom">
                <div class="container">
                    <div class="row">
                        
                       <?php while(have_posts() ) : the_post(); ?>

                           <?php the_content(); ?>

                       <?php endwhile; ?>     

                       

                    </div>
                </div>
            </section>
</div>
<?php get_footer(); ?>