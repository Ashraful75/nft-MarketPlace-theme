<div class="spacer-single"></div>
<article class="post-single">
  <div class="post-info2">
    <h2 class="blog-post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
    <h6 class="upper"><span>By</span><a href="<?php the_author(); ?>"> <?php the_author(); ?></a><span class="dot"></span><span><?php the_time('d F Y'); ?></span><span class="dot"></span><?php the_tags(); ?></h6> <br>
  </div>
  <div class="post-media"><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a></div> <br>
    <div class="post-body">
      
      <?php if(is_single() ) : ?>

    <?php the_content(); ?>

    <?php else : ?>

    <?php 
      $readMore = '<p><a href="'.get_permalink().'" class="read-more-btn">Read More</a></p>';
      echo wp_trim_words(get_the_content(), 80, $readMore);
    ?>
  <?php endif; ?>
      
    </div>
  </article> 
   <div class="spacer-single"></div>
   <hr>  