 <!-- footer begin -->
        <footer>
            
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-1">
                    	<?php dynamic_sidebar('sidebar-1'); ?>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-1">
                        <?php dynamic_sidebar('sidebar-2'); ?>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-1">
                        <?php dynamic_sidebar('sidebar-3'); ?>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-1">
                        <?php dynamic_sidebar('sidebar-4'); ?>
                    </div>
                </div>
            </div>
            <div class="subfooter">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="de-flex">
                                <div class="de-flex-col">
                                    <a href="03_grey-index.html">
                                        <span class="copy"><?php $nft = get_option('nft_option'); ?><?php echo $nft['copyright-text']; ?></span>
                                    </a>
                                </div>
                                <div class="de-flex-col">
                                    <div class="social-icons">
                                    <?php $group_icons = $nft['social-icons']; ?>
                                    <?php foreach ( $group_icons as $single_icon ) : ?>
                                        <a href="<?php echo $single_icon['select-icon-link']; ?>"><i class="<?php echo $single_icon['select-icon']; ?>"></i></a>
                                    <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer close -->
        
    </div>


<?php wp_footer(); ?>
</body>

</html>