        <?php get_header(); ?>
        <!-- content begin -->
        <div class="no-bottom no-top" id="content">
            <div id="top"></div>
            <section id="section-hero" aria-label="section" class="pt20 pb20 vh-100" data-bgimage="url(<?php echo get_template_directory_uri(); ?>/images/background/8.jpg) bottom">
                <div id="particles-js"></div>
                <div class="v-center">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <div class="spacer-single"></div>
                                <h6 class="wow fadeInUp" data-wow-delay=".5s"><span class="text-uppercase id-color-2">Gigaland Market</span></h6>
                                <div class="spacer-10"></div>
                                <h1 class="wow fadeInUp" data-wow-delay=".75s">Create, sell and collect digital items.</h1>
                                <p class="wow fadeInUp lead" data-wow-delay="1s">
                                Unit of data stored on a digital ledger, called a blockchain, that certifies a digital asset to be unique and therefore not interchangeable</p>
                                <div class="spacer-10"></div>
                                <a href="03_grey-explore.html" class="btn-main wow fadeInUp lead" data-wow-delay="1.25s">Explore</a>                                
                                <div class="row">
                                    <div class="spacer-single"></div>
                                    <div class="row">
                                            <div class="col-lg-4 col-md-6 col-sm-4 wow fadeInRight mb30" data-wow-delay="1.1s">
                                                <div class="de_count text-left">
                                                    <h3><span>94215</span></h3>
                                                    <h5 class="id-color">Collectibles</h5>
                                                </div>
                                            </div>

                                            <div class="col-lg-4 col-md-6 col-sm-4 wow fadeInRight mb30" data-wow-delay="1.4s">
                                                <div class="de_count text-left">
                                                    <h3><span>27</span>k</h3>
                                                    <h5 class="id-color">Auctions</h5>
                                                </div>
                                            </div>

                                            <div class="col-lg-4 col-md-6 col-sm-4 wow fadeInRight mb30" data-wow-delay="1.7s">
                                                <div class="de_count text-left">
                                                    <h3><span>4</span>k</h3>
                                                    <h5 class="id-color">NFT Artist</h5>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div class="col-md-6 xs-hide">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/misc/women-with-vr.png" class="img-fluid wow fadeInUp" data-wow-delay=".75s" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- section begin -->
            <section aria-label="section" class="no-bottom">
                <div class="container">
                    <div class="row">

                    <?php $posts = new WP_Query(array(
                        'post_type' => 'post',
                        'posts_per_page' => 3,
                    )); ?>
                        
                       <?php while( $posts->have_posts() ) : $posts->the_post(); ?>

                           <?php get_template_part('template-part/content'); ?>

                       <?php endwhile; ?>     

                       

                    </div>
                </div>
            </section>

            
        </div>
        <!-- content close -->

        <a href="#" id="back-to-top"></a>
        
       <?php get_footer(); ?>